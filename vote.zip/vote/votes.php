<?php 
      

    function connect()
    {
      $db = null ;
      try {
          $db = new PDO("mysql:host=localhost;dbname=vote","root","",array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
          $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
      } catch (PDOException $e) {
          $db = null ;
      }
      return $db;
    }  

        $db = connect();
        $sql = $db->prepare("SELECT * FROM vote");
        $sql->execute();
        if($sql->rowCount()==0) header("Location:index.php");
        $rows = $sql->fetchAll(PDO::FETCH_ASSOC);
        

?>


    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <title>
            قائمة الأصوات - كلية العلوم
        </title>
        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
        <link rel="stylesheet" type="text/css" href="assets/css/font-awesome/css/font-awesome.css">
        <!-- CSS Files -->
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="assets/css/util.css">
        <style type="text/css">
          .results-container
          {
              margin-top: 20px;
          }
          
          .black-text
          {
              color: #000 !important;
          }
          table
          {
              margin: auto;
          }
          table th
          {
              padding:10px;
              text-align: center;
              background-color: #ddd;
          }
          table td
          {
              padding:10px;
              text-align: center;   
          }
        </style>
    </head>

    <body>

    <script type="text/javascript">
      function getFullDate()
        {
          var today = new Date();
          var dd = today.getDate();
          var mm = today.getMonth()+1; 
          var yyyy = today.getFullYear();
          if(dd<10) 
          {
              dd='0'+dd;
          } 
          if(mm<10) 
          {
              mm='0'+mm;
          } 
          today = dd+'/'+mm+'/'+yyyy;
          return today;
        }
    </script>

    <div class="">
        
        <div class="main-panel">
         
            <div class="content">
                <div class="container-fluid">
                    <div class="row m-t-50">

                        <div class="text-center">
                          <img src="assets/img/flag.png" width="10%" height="10%">
                        </div>

                        <div class="fs-14 text-center ubuntu ar-en m-t-40">جامعة فرحات عباس سطيف 1</div>
                        <div class="fs-22 text-center">كلية العلوم</div>

                        <div class="m-t-40 text-center ar-en">
                          قائمة الأصوات
                        </div>

                        <div class="text-center m-t-30">

                          
                            <div class="results-container text-center">
                                <table class="table-bordered">
                                    <thead>
                                        <th>رقم الصوت</th>
                                        <th>رقم بطاقة الطالب</th>
                                        <th>توقيت إرسال التصويت</th>
                                        <th>الصوت</th>
                                    </thead>
                                    <tbody>
                                        <?php 
                                          foreach($rows as $row)
                                          {
                                        ?>
                                              <tr>
                                                <td class="ar-en"><?= $row['id']?></td>
                                                <td class="ar-en"><?= $row['studentID']?></td>
                                                <td class="ar-en"><?= $row['timestamp']?></td>
                                                <td class="ar-en"><?= ($row['choice']=='oui' ? '<span class="bold">مع</span> مواصلة الإضراب' : '<span class="bold">ضد</span>  مواصلة الإضراب')?></td>
                                              </tr>
                                        <?php 
                                          }
                                        ?>
                                    </tbody>
                                </table>
                            </div>

                            <!--<div class="text-center m-t-40"><a class="btn btn-info" href="index.php">الصفحة الرئيسية</a> <a class="btn btn-info" href="results.php">إحصائيات</a></div>-->
                          
                        </div>
                       
                    </div>
                </div>
                <div class="m-t-80 bold text-center ubuntu ar-en"><script type="text/javascript">document.write(getFullDate());</script></div>
            </div>
            
        </div>
    </div>

    
    </body>

    
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
    <script src="assets/js/sweetalert.js"></script>

    <script type="text/javascript">
        
        $(document).ready(function(){
            
            
            
        });

    </script>

    </html>