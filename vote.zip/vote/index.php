<?php 
      

    function connect()
    {
      $db = null ;
      try {
          $db = new PDO("mysql:host=localhost;dbname=vote","root","",array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
          $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
      } catch (PDOException $e) {
          $db = null ;
      }
      return $db;
    }  

    if(isset($_POST["id"]) && isset($_POST["choice"]) && isset($_POST["valid"]))
    {
        if ($_POST['id']!=null && $_POST["choice"]!=null && $_POST['valid'])
        {
            $id = $_POST["id"];
            $choice = $_POST["choice"];
            $db = connect();
            try 
            {
                $insert = $db->prepare("INSERT INTO vote (studentID,choice) VALUES (?,?)");
                $insert->execute(array($id,$choice));
                if($insert)
                {
                  $lastID = null; 
                  $lastID = $db->lastInsertId();
                  echo json_encode(array("id"=>$lastID,"success"=>true));
                }
                else{
                  echo json_encode(array("message"=>"تم التصويت باستعمال هذا الرقم من قبل !","success"=>false));
                }
                exit;
            } catch (Exception $e)
            {
                echo json_encode(array("message"=>"تم التصويت باستعمال هذا الرقم من قبل !","success"=>false));
                exit;
            }
            
        }
    }

?>


    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <title>
            التصويت - كلية العلوم
        </title>
        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
        <link rel="stylesheet" type="text/css" href="assets/css/font-awesome/css/font-awesome.css">
        <!-- CSS Files -->
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="assets/css/util.css">
    </head>

    <body>

    <script type="text/javascript">
      function getFullDate()
        {
          var today = new Date();
          var dd = today.getDate();
          var mm = today.getMonth()+1; 
          var yyyy = today.getFullYear();
          if(dd<10) 
          {
              dd='0'+dd;
          } 
          if(mm<10) 
          {
              mm='0'+mm;
          } 
          today = dd+'/'+mm+'/'+yyyy;
          return today;
        }
    </script>

    <div class="">
        
        <div class="main-panel">
         
            <div class="content">
                <div class="container-fluid">
                    <div class="row m-t-50">

                        <div class="text-center">
                          <img src="assets/img/flag.png" width="10%" height="10%">
                        </div>

                        <div class="fs-14 text-center ubuntu ar-en m-t-40">جامعة فرحات عباس سطيف 1</div>
                        <div class="fs-22 text-center">كلية العلوم</div>

                        <div class="m-t-40 text-center">
                          إضافة صوت جديد
                        </div>

                        <div class="text-center m-t-30">
                          <form id="form">
                            <input class="fs-16 ar-en m-b-20" type="text" name="id" id="id" placeholder="رقم بطاقة الطالب" required="">
                            <div class="form-group">
                              <div>
                                <input class="choice" type="radio" name="choice" value="oui" required="">
                                <label>مع مواصلة الإضراب</label>
                              </div>
                              <div>
                                <input class="choice" type="radio" name="choice" value="non" required="">
                                <label>ضد مواصلة الإضراب</label>
                              </div>
                            </div>
                            <button class="btn btn-success">إرسال الصوت</button>
                          </form>

                          
                        </div>

                        <!--<div class="text-center m-t-40"><a class="btn btn-info" href="votes.php">قائمة الأصوات</a> <a class="btn btn-info" href="results.php">إحصائيات</a></div>-->
                       
                    </div>
                </div>
                <div class="m-t-80 bold text-center ubuntu ar-en"><script type="text/javascript">document.write(getFullDate());</script></div>
            </div>
            
        </div>
    </div>

    
    </body>

    
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
    <script src="assets/js/sweetalert.js"></script>

    <script type="text/javascript">
        
        $(document).ready(function(){
            
            $("#form").submit(function(ev){
                ev.preventDefault();
                var id = $("#id").val();
                var choice = $('input[name=choice]:checked', '#form').val();
                $.ajax({
                  type:"POST",
                  url:"index.php",
                  data:"id="+id+"&choice="+choice+"&valid=true",
                  dataType:"json",
                  success:function(data)
                  {
                      console.log(data);
                      if(data["success"])
                      {
                          swal({
                            type: 'success',
                            title: '',
                            confirmButtonText: 'إغلاق',
                            html: "<div class='ubuntu text-success fs-16 bold ar-en p-b-5 p-t-5'>تمت إضافة الصوت بنجاح <div class='ar-en'>رقم الصوت : "+data["id"]+"</div></div>",
                            preConfirm:function()
                            {
                                window.location.reload();
                            }
                          });
                      }else{
                          swal({
                              type: 'error',
                              title: 'خطأ',
                              confirmButtonText: 'إغلاق',
                              html: "<div class='ubuntu text-danger ar-en fs-12 p-b-5 p-t-5'>"+data['message']+"</div>"
                          });
                      }
                  }
                });
            });
            
        });

    </script>

    </html>