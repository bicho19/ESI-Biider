<?php 
      

    function connect()
    {
      $db = null ;
      try {
          $db = new PDO("mysql:host=localhost;dbname=vote","root","",array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
          $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
      } catch (PDOException $e) {
          $db = null ;
      }
      return $db;
    }  

    //if(isset($_POST["username"]) && isset($_POST["password"]))
    //{
        $db = connect();
        $sql = $db->prepare("SELECT * FROM vote");
        $sql->execute();
        $all = $sql->rowCount();
        // oui
        $sql = $db->prepare("SELECT * FROM vote WHERE choice = 'oui'");
        $sql->execute();
        $oui = $sql->rowCount();
        // non
        $sql = $db->prepare("SELECT * FROM vote WHERE choice = 'non'");
        $sql->execute();
        $non = $sql->rowCount();
        //
        if($all==0) header("Location:index.php");
        $ouiPercentage = ($oui/$all)*100;
        $nonPercentage = 100-$ouiPercentage;
    //}

?>


    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <title>
            صفحة نتائج التصويت - كلية العلوم
        </title>
        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
        <link rel="stylesheet" type="text/css" href="assets/css/font-awesome/css/font-awesome.css">
        <!-- CSS Files -->
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="assets/css/util.css">
        <style type="text/css">
          .results-container
          {
              margin-top: 40px;
          }
          .results-container .progress-bars
          {
              margin-top: 40px !important;
              width: 50%;
              margin: auto;
          }
          .black-text
          {
              color: #000 !important;
          }
        </style>
    </head>

    <body>

    <script type="text/javascript">
      function getFullDate()
        {
          var today = new Date();
          var dd = today.getDate();
          var mm = today.getMonth()+1; 
          var yyyy = today.getFullYear();
          if(dd<10) 
          {
              dd='0'+dd;
          } 
          if(mm<10) 
          {
              mm='0'+mm;
          } 
          today = dd+'/'+mm+'/'+yyyy;
          return today;
        }
    </script>

    <div class="">
        
        <div class="main-panel">
         
            <div class="content">
                <div class="container-fluid">
                    <div class="row m-t-50">

                        <div class="text-center">
                          <img src="assets/img/flag.png" width="10%" height="10%">
                        </div>

                        <div class="fs-14 text-center ubuntu ar-en m-t-40">جامعة فرحات عباس سطيف 1</div>
                        <div class="fs-22 text-center">كلية العلوم</div>

                        <div class="m-t-40 text-center ar-en">
                          نتائج التصويت حتى الآن
                        </div>

                        <div class="text-center m-t-30">

                          
                            <div class="results-container">
                              العدد الكلي للمصوتين : <span class="ar-en bold"><?= $all; ?></span> طالب
                              <div class="progress-bars">
                                  <div class="bold m-b-15 align-right ar-en">مع مواصلة الإضراب <?= $oui?>/<?=$all; ?></div>
                                  <div class="progress">
                                    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="<?= $ouiPercentage ?>"
                                    aria-valuemin="0" aria-valuemax="100" style="width:<?= $ouiPercentage ?>%">
                                      <span class="ar-en bold"><?= $ouiPercentage ?>%</span>
                                    </div>
                                  </div>
                                  <div class="bold m-b-15 align-right ar-en">ضد مواصلة الإضراب <?= $non?>/<?=$all; ?></div>
                                  <div class="progress">
                                    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="70"
                                    aria-valuemin="0" aria-valuemax="100" style="width:<?= $nonPercentage ?>%">
                                      <span class="ar-en bold"><?= $nonPercentage ?>%</span>
                                    </div>
                                  </div>
                              </div>
                            </div>

                            <!--<div class="text-center m-t-40"><a class="btn btn-info" href="index.php">الصفحة الرئيسية</a> <a class="btn btn-info" href="votes.php">عرض قائمة الأصوات</a></div>-->
                          
                        </div>
                       
                    </div>
                </div>
                <div class="m-t-80 bold text-center ubuntu ar-en"><script type="text/javascript">document.write(getFullDate());</script></div>
            </div>
            
        </div>
    </div>

    
    </body>

    
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
    <script src="assets/js/sweetalert.js"></script>

    <script type="text/javascript">
        
        $(document).ready(function(){
            
            
            
        });

    </script>

    </html>