/************************************************************/
/* SUCCESS */

function successAdd()
{
	swal({
        type: 'success',
        title: 'تمت عملية الإضافة بنجاح !',
        confirmButtonColor: '#47a44b',
        confirmButtonText: 'إنهاء',
    });
}
function successDelete()
{
	swal({
        type: 'success',
        title: 'تمت عملية الحذف بنجاح !',
        confirmButtonColor: '#47a44b',
        confirmButtonText: 'إنهاء',
    });
}
function successEdit()
{
	swal({
        type: 'success',
        title: 'تمت عملية التعديل بنجاح !',
        confirmButtonColor: '#47a44b',
        confirmButtonText: 'إنهاء',
    });
}

/************************************************************/
/* FAIL */

function failAdd()
{
	swal({
        type: 'error',
        title: 'حدث خطأ أثناء عملية الإضافة ، يرجى المحاولة مرة أخرى !',
        confirmButtonColor: '#47a44b',
        confirmButtonText: 'إنهاء',
    });
}
function failDelete()
{
	swal({
        type: 'error',
        title: 'حدث خطأ أثناء عملية الحذف ، يرجى المحاولة مرة أخرى !',
        confirmButtonColor: '#47a44b',
        confirmButtonText: 'إنهاء',
    });
}
function failEdit()
{
	swal({
        type: 'error',
        title: 'حدث خطأ أثناء عملية التعديل ، يرجى المحاولة مرة أخرى !',
        confirmButtonColor: '#47a44b',
        confirmButtonText: 'إنهاء',
    });
}